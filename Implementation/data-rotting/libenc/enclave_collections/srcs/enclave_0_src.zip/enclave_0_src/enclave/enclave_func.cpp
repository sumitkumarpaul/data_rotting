/**
*
* MIT License
*
* Copyright (c) Open Enclave SDK contributors.
*
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the "Software"), to deal
* in the Software without restriction, including without limitation the rights
* to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be included in all
* copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
* OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
* SOFTWARE
*
*/

#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "../common/common.h"


extern "C"
{
    int enclave_0_ecall_0(int a, int b);
};

int enclave_0_ecall_0(int a, int b)
{
    int c;

    t_print(PRINT_PREFIX "+++++++++ Simulation mode example \n");
    
    t_print(PRINT_PREFIX "+++++++++ Started execution of sample ecall:%s(%d, %d)\n", __func__, a, b);

    /* Sample operation */
    c = a + b;
    
    t_print(PRINT_PREFIX "Performing (%d + %d) = %d\n", a, b, c);
    
    t_print(PRINT_PREFIX "+++++++++ Ending execution of sample ecall and returning = %d\n", c);
    
    return c;
}
