/**
*
* MIT License
*
* Copyright (c) Open Enclave SDK contributors.
*
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the "Software"), to deal
* in the Software without restriction, including without limitation the rights
* to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be included in all
* copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
* OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
* SOFTWARE
*
*/

#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "../common/common.h"
#include "../common/data_access.h"
#include "../common/data_provision.h"

char g_ts_ip[16];
int  g_ts_port;

extern "C"
{
    int enclave_0_ecall_0(int a, int b);
    int ecall_check_personal_loan_eligibility(char *result, int *p_result_len, int max_result_sz, char *ts_server_ip, int ts_server_port);
};

char eligibility_str[200] = {0};

int enc_check_SSN()
{
    int ret = -1;


    ret = 0;
exit:

    return ret;
}

int enc_check_age()
{
    int ret = -1;


    ret = 0;
exit:

    return ret;
}

int enc_check_income()
{
    int ret = -1;


    ret = 0;
exit:

    return ret;
}

int ecall_check_personal_loan_eligibility(char *result, int *p_result_len, int max_result_sz, char *ts_server_ip, int ts_server_port)
{
    int ret = -1;
    X509* priv_data_x509 = NULL;
    int result_len;

    /* Initialize result with dummy value */
    strncpy(eligibility_str, "NOT-OK", sizeof("NOT-OK"));
    *p_result_len = 0;
    
    g_ts_port = ts_server_port; // convert to char* to int

    memcpy(g_ts_ip, ts_server_ip, strnlen(ts_server_ip, 16));
    
    enc_print_log(ENC_DEBUG_LEVEL_INFO, "Starting to evaluate the eligibility of data-owner for obtaining personal loan\n");
    
    priv_data_x509 = enc_private_data_file_open(ENC_DO_PRIV_DATA_FILE);

    if (priv_data_x509 == NULL)
    {
        enc_print_log(ENC_DEBUG_LEVEL_ERROR, "Cannot access the private data-file of the data-owner\n");
        goto exit;
    }

    /* Check whether age is in-between 18 and 55 */
    if (enc_check_age())
    {
        enc_print_log(ENC_DEBUG_LEVEL_ERROR, "Problem while checking the age\n");
        goto exit;
    }

    /* Check whether the SSN number is in the black-list */
    if (priv_data_x509 == NULL)
    {
        enc_print_log(ENC_DEBUG_LEVEL_ERROR, "Problem while checking the SSN\n");
        goto exit;
    }

    /* Check whether the annual income is over 50000$ */
    if (priv_data_x509 == NULL)
    {
        enc_print_log(ENC_DEBUG_LEVEL_ERROR, "\n");
        goto exit;
    }

    /* If everything is fine the return OK */
    strncpy(eligibility_str, "OK", sizeof("OK"));

    if (enc_encrypt_result(eligibility_str, sizeof("OK"), g_enc_buffer, &result_len) < 0)
    {
        enc_print_log(ENC_DEBUG_LEVEL_ERROR, "Error while encrypting the result\n");
        goto exit;
    }
    
    if (max_result_sz < result_len)
    {
        enc_print_log(ENC_DEBUG_LEVEL_ERROR, "Provided buffer is too short for the operation");
        goto exit;
    }
    
    /* Copy to the user buffer */
    memcpy(result, g_enc_buffer, result_len);
    
    *p_result_len = result_len;

    enc_print_log(ENC_DEBUG_LEVEL_INFO, "Returning the encrypted result to the data-owner, having size = %d\n", *p_result_len);
    
    ret = 0;
exit:
    if (priv_data_x509 != NULL)
    {
        enc_private_data_file_close(priv_data_x509);
    }

    return ret;
}

int enclave_0_ecall_0(int a, int b)
{
    int c;
    
    enc_print_log(ENC_DEBUG_LEVEL_ERROR, "+++++++++ Hardware mode example \n");

    enc_print_log(ENC_DEBUG_LEVEL_ERROR, "+++++++++ Started execution of sample ecall:%s(%d, %d)\n", __func__, a, b);

    /* Sample operation */
    c = a + b;
    
    enc_print_log(ENC_DEBUG_LEVEL_ERROR, "Performing (%d + %d) = %d\n", a, b, c);
    
    enc_print_log(ENC_DEBUG_LEVEL_ERROR, "+++++++++ Ending execution of sample ecall and returning = %d\n", c);
    
    return c;
}
